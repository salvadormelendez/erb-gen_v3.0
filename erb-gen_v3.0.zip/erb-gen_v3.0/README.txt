INSTRUCTIONS ON HOW TO USE THE ERB GENERATOR:

1.- Unzip the file "erb-gen_v3.0.zip" into your "Desktop".
    You should have a folder named "erb-gen" with several files.

2.- Export your Dradis findings into your "Desktop".
    It should be a zip file called "dradis-export". Do NOT rename it and do NOT unzip it.

3.- Open a Terminal window and navigate to the "erb-gen" folder (cd /root/Desktop/erb-gen).

4.- Run the tool with this command --> python3 erb-gen.py

5.- Use the GUI to generate your PPTX file; it should be self-explanatory.

6.- When you hit the "PPTX" button, you should have your ERB in your "Desktop".

7.- Use Microsoft Office PowerPoint to open the ERB file (recommended).

8.- Complete the slides that are specific to your event.

Enjoy!

Please send any feedback to --> Salvador Melendez (salvador.melendez3.civ@army.mil)